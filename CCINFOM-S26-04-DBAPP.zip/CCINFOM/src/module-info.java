module CCINFOM {
    requires java.sql;
    requires java.desktop; 
}